import { ItemType } from '../types';

/**
 * A local library of quotes to replace the AI service.
 * This makes the game completely offline-compatible and reliable.
 */

const QUOTES = {
  // Score > 2000
  perfect: [
    "我从未见过如此生机勃勃的农场！这简直就是奇迹。",
    "你让我想起了年轻时的自己... 干得漂亮，孩子。",
    "这种完美的表现，值得我在神龛前为你点亮所有的蜡烛。",
    "太惊人了！哪怕是齐先生看到这样的成绩也会脱帽致敬。",
    "这就是星露谷的精神！勤劳，勇敢，还有... 惊人的胃口！",
    "我已经没有什么可以教你的了。你不仅是一名农夫，更是一位传奇。",
    "看到你如此优秀，我感到无比欣慰... 农场的未来交给你，我放心了。",
    "这简直比完美的五彩碎片还要耀眼！",
    "哪怕在天堂，我也能感受到你刚才那场盛宴的热情！",
    "无可挑剔！皮埃尔的杂货店如果能有你这样的顾客，早就发财了。",
    "即使是传说中的传说之鱼，也比不上你刚才的表现。",
    "你的名字将会被刻在鹈鹕镇的荣耀榜上！",
    "哈哈！这才是我的孙子/孙女！让祖家感到骄傲吧！",
    "多么壮观的景象！就像春天盛开的第一朵蓝色爵士花一样美好。",
    "如果是你的话，或许真的能解开社区中心的全部秘密。"
  ],
  
  // Score 1000 - 1999
  great: [
    "干得不错！农场交到你手里真是个正确的决定。",
    "这一顿大餐真是丰盛，看得我都有些饿了... 如果幽灵能吃东西的话。",
    "不仅要努力工作，也要好好吃饭。你做得很好。",
    "虽然还有提升的空间，但我已经看到了你眼中的光芒。",
    "就像精心照料的南瓜一样，你的努力结出了硕果。",
    "如果是路易斯镇长看到，一定会给你颁发一枚金星勋章。",
    "继续保持！星露谷的未来充满希望。",
    "我看好你，孩子。你有着成为顶级农场主的潜力。",
    "这比我在星之果实餐吧见过的任何比赛都要精彩！",
    "不错，真不错。记得把多余的能量用在开垦荒地上。",
    "你的表现就像秋天的蔓越莓酱一样甜美。",
    "看来你已经适应了山谷的生活，我为你感到高兴。",
    "稳扎稳打。这就是经营农场的秘诀。",
    "今天的收成不错，不是吗？好好享受这份喜悦吧。",
    "只要心中有爱，哪怕是普通的防风草也能变成美味佳肴。"
  ],

  // Score 500 - 999
  good: [
    "还算过得去。万事开头难，不要气馁。",
    "只要没有把农场烧掉，我就觉得你做得很好了。继续加油。",
    "嗯... 看来你还需要多练习一下怎么分辨食物和杂草。",
    "别担心，孩子。就算是我，当年也经常搞砸。",
    "记住，生活不仅仅是竞争，享受过程也很重要。",
    "也许下次运气会好一点？比如多来点披萨，少来点史莱姆。",
    "至少你没有饿着肚子，这就是好事。",
    "这种表现... 只能算是一般的品质吧，离金星还差一点。",
    "不要灰心。并不是每天都是艳阳高照的。",
    "慢慢来。罗马不是一天建成的，农场也是。",
    "多去威利那里钓钓鱼，或许能锻炼你的反应速度。",
    "还行吧。至少比乔家超市的那些冷冻食品有活力多了。",
    "保持耐心。大自然会回馈每一个勤劳的人。",
    "虽然不是最完美的，但我看到了你的努力。",
    "也许你应该去向格斯请教一下关于食物的知识？"
  ],

  // Score < 500
  bad: [
    "哎呀... 看来今天不太顺利。是被石头绊倒了吗？",
    "孩子，那是炸弹，不是蓝莓！下次要看清楚。",
    "我都替你感到胃疼... 记得去找哈维医生看看。",
    "这一团糟... 简直像是我那个荒废了多年的院子。",
    "没关系，失败是成功之母。虽然这次真的很失败。",
    "也许你不适合当大胃王... 试试去矿洞挖矿如何？",
    "天哪，如果你这样经营农场，我们很快就要破产了。",
    "振作点！别让那些讨厌的乌鸦嘲笑你。",
    "哪怕是莱纳斯在垃圾桶里找到的晚餐，可能都比这强点...",
    "好吧，我们假装这一局从来没有发生过。",
    "如果我是你，我现在就去睡觉，直接跳到第二天。",
    "即使是幽灵也会感到尴尬... 如下次努力吧。",
    "看来你需要多吃点那些加运气的香辣鳗鱼了。",
    "别放弃！即使是最糟糕的季节也会过去。",
    "或许种地更适合你，而不是吃东西..."
  ],

  // Specific Events: Stardrop found
  stardrop: [
    "你尝到了星之果实的味道！那是宇宙中最美妙的感觉，对吧？",
    "哇！一颗星之果实！你的能量上限提升了吗？",
    "即使在我那个年代，星之果实也是极为罕见的宝物！",
    "那颗紫色的果实... 它让我想起了最爱的事物。",
    "运气不错！星之果实可是大自然的恩赐。",
    "一旦尝过星之果实，其他的食物都会显得索然无味。",
    "那一刻，你的脑海中浮现了什么？是'星露谷'吗？",
    "有了这股力量，你可以从黎明工作到深夜了！"
  ],

  // Specific Events: Bomb Eaten
  bomb: [
    "刚才那一声巨响... 你还好吗？",
    "天哪！我看见你吞下了一个樱桃炸弹！这太疯狂了！",
    "即使再饿，也不应该吃炸弹啊，孩子...",
    "幸好这是游戏，否则我的农场就要变成大坑了！",
    "下次看到红色的闪烁物体，记得跑开，而不是张嘴！",
    "你的胃是铁做的吗？那可是货真价实的火药！",
    "肯特如果在场，一定会吓得脸色发白。",
    "虽然很有爆炸性，但我建议你还是坚持吃普通的食物。"
  ],

  // Specific Events: Rare Item (Prismatic Shard / Magic Rock Candy)
  rare: [
    "那是... 五彩碎片吗？那是无价之宝啊！",
    "魔法糖冰棍！那种味道能让时间都静止下来。",
    "你今天的运气简直好得离谱！精灵们一定在眷顾你。",
    "居然找到了这么稀有的东西，博物馆长冈瑟会嫉妒的。",
    "好好珍惜那份好运。这在矿洞深处可是很难遇到的。"
  ],

  // Tie Game
  tie: [
    "一场势均力敌的较量！你们两个都非常出色。",
    "难分伯仲！看来星露谷拥有两位同样优秀的守护者。",
    "这就是友谊的力量吗？连分数都一模一样。",
    "平局！这意味着你们必须分享胜利的果实（和披萨）。",
    "看来今天没有输家，只有两位饱餐一顿的农夫。"
  ]
};

const getRandom = (arr: string[]) => arr[Math.floor(Math.random() * arr.length)];

export const generateGameProphecy = async (scoreP1: number, scoreP2: number, itemsCollected: string[]) => {
  // Simulate delay for effect (optional, but keep it 0 for instant local feel)
  
  const winningScore = Math.max(scoreP1, scoreP2);
  const isTie = scoreP1 === scoreP2;
  const hasStardrop = itemsCollected.includes(ItemType.STARDROP);
  const hasBomb = itemsCollected.includes(ItemType.BOMB);
  const hasRare = itemsCollected.includes(ItemType.PRISMATIC_SHARD) || itemsCollected.includes(ItemType.MAGIC_ROCK_CANDY);

  // 1. Priority: Bomb (It's funny/tragic)
  if (hasBomb && Math.random() > 0.6) {
    return getRandom(QUOTES.bomb);
  }

  // 2. Priority: Stardrop or Rare (Exciting)
  if (hasStardrop && Math.random() > 0.5) {
    return getRandom(QUOTES.stardrop);
  }
  if (hasRare && Math.random() > 0.5) {
    return getRandom(QUOTES.rare);
  }

  // 3. Priority: Tie
  if (isTie) {
    return getRandom(QUOTES.tie);
  }

  // 4. Score Based
  if (winningScore >= 2000) {
    return getRandom(QUOTES.perfect);
  } else if (winningScore >= 1000) {
    return getRandom(QUOTES.great);
  } else if (winningScore >= 500) {
    return getRandom(QUOTES.good);
  } else {
    return getRandom(QUOTES.bad);
  }
};