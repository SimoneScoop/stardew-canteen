
// Simple retro synthesizer using Web Audio API to avoid external asset loading issues
class AudioService {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private musicGain: GainNode | null = null;
  private isMuted: boolean = false;
  private bgmInterval: number | null = null;
  private isPlayingBGM: boolean = false;

  constructor() {
    try {
      // Defer initialization until interaction
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      if (AudioContextClass) {
        this.ctx = new AudioContextClass();
        this.masterGain = this.ctx.createGain();
        this.masterGain.gain.value = 0.3; // Default SFX volume
        this.masterGain.connect(this.ctx.destination);

        this.musicGain = this.ctx.createGain();
        this.musicGain.gain.value = 0.15; // Lower volume for BGM
        this.musicGain.connect(this.ctx.destination);
      }
    } catch (e) {
      console.error('AudioContext not supported');
    }
  }

  // Resume context on user interaction
  public async init() {
    if (this.ctx && this.ctx.state === 'suspended') {
      await this.ctx.resume();
    }
  }

  private createOscillator(type: OscillatorType, frequency: number, duration: number, startTime: number) {
    if (!this.ctx || !this.masterGain) return;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    
    osc.type = type;
    osc.frequency.setValueAtTime(frequency, startTime);
    
    gain.gain.setValueAtTime(0.5, startTime);
    gain.gain.exponentialRampToValueAtTime(0.01, startTime + duration);

    osc.connect(gain);
    gain.connect(this.masterGain);

    osc.start(startTime);
    osc.stop(startTime + duration);
  }

  // --- SFX ---

  public playClick() {
    this.init();
    if (!this.ctx || this.isMuted) return;
    const t = this.ctx.currentTime;
    this.createOscillator('square', 800, 0.1, t);
  }

  public playEat() {
    // "Pickup" sound: High pitched chime/blip (Stardew style)
    if (!this.ctx || this.isMuted) return;
    const t = this.ctx.currentTime;
    
    // First tone
    const osc1 = this.ctx.createOscillator();
    const gain1 = this.ctx.createGain();
    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(1000, t);
    gain1.gain.setValueAtTime(0.4, t);
    gain1.gain.exponentialRampToValueAtTime(0.01, t + 0.1);
    osc1.connect(gain1);
    // @ts-ignore
    gain1.connect(this.masterGain);
    osc1.start(t);
    osc1.stop(t + 0.1);

    // Second tone (slightly delayed, higher)
    const osc2 = this.ctx.createOscillator();
    const gain2 = this.ctx.createGain();
    osc2.type = 'sine';
    osc2.frequency.setValueAtTime(1500, t + 0.05);
    gain2.gain.setValueAtTime(0.4, t + 0.05);
    gain2.gain.exponentialRampToValueAtTime(0.01, t + 0.2);
    osc2.connect(gain2);
    // @ts-ignore
    gain2.connect(this.masterGain);
    osc2.start(t + 0.05);
    osc2.stop(t + 0.2);
  }

  public playBad() {
    // "Bad" sound: Low pitched "womp"
    if (!this.ctx || this.isMuted) return;
    const t = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(150, t);
    osc.frequency.linearRampToValueAtTime(100, t + 0.2);
    
    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.2);

    osc.connect(gain);
    // @ts-ignore
    gain.connect(this.masterGain);

    osc.start(t);
    osc.stop(t + 0.2);
  }

  public playBomb() {
    // Noise burst for explosion
    if (!this.ctx || this.isMuted) return;
    const t = this.ctx.currentTime;
    const bufferSize = this.ctx.sampleRate * 0.5; // 0.5 seconds
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;
    const gain = this.ctx.createGain();
    
    // Lowpass filter to make it sound like a deep boom
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.value = 1000;

    gain.gain.setValueAtTime(1, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.5);

    noise.connect(filter);
    filter.connect(gain);
    // @ts-ignore
    gain.connect(this.masterGain);
    
    noise.start(t);
  }

  public playFanfare() {
    // Simple victory arpeggio
    if (!this.ctx || this.isMuted) return;
    const t = this.ctx.currentTime;
    
    // C Major Arpeggio
    this.createOscillator('triangle', 523.25, 0.2, t);       // C5
    this.createOscillator('triangle', 659.25, 0.2, t + 0.1); // E5
    this.createOscillator('triangle', 783.99, 0.4, t + 0.2); // G5
    this.createOscillator('triangle', 1046.50, 0.6, t + 0.3); // C6
  }

  // --- BGM ---

  public startBGM() {
    this.init();
    if (this.isPlayingBGM || !this.ctx || !this.musicGain) return;
    this.isPlayingBGM = true;
    
    let noteIndex = 0;
    // A rustic, happy pentatonic-ish sequence simulating a flute/synth
    const melody = [
      392.00, 329.63, 261.63, 329.63, // G E C E
      392.00, 392.00, 440.00, 392.00, // G G A G
      329.63, 261.63, 293.66, 261.63, // E C D C
      196.00, 261.63, 329.63, 293.66  // G3 C E D
    ];

    const playStep = () => {
      if (!this.isPlayingBGM || !this.ctx || !this.musicGain) return;
      
      const t = this.ctx.currentTime;
      const freq = melody[noteIndex % melody.length];
      const duration = 0.3; // seconds per note

      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'triangle'; // Flute-like tone
      osc.frequency.value = freq;
      
      // Soft envelope
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.2, t + 0.05);
      gain.gain.exponentialRampToValueAtTime(0.01, t + duration);

      osc.connect(gain);
      gain.connect(this.musicGain);

      osc.start(t);
      osc.stop(t + duration);

      noteIndex++;
    };

    // Play a note every 400ms
    // @ts-ignore
    this.bgmInterval = window.setInterval(playStep, 400);
  }

  public stopBGM() {
    this.isPlayingBGM = false;
    if (this.bgmInterval) {
      clearInterval(this.bgmInterval);
      this.bgmInterval = null;
    }
  }
}

export const audioService = new AudioService();
