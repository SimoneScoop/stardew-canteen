

export enum GameState {
  LOADING = 'LOADING',
  MENU = 'MENU',
  PLAYING = 'PLAYING',
  PAUSED = 'PAUSED', // Added PAUSED state
  GAME_OVER = 'GAME_OVER',
}

export interface Point {
  x: number;
  y: number;
}

export interface Item {
  id: number;
  x: number;
  y: number;
  type: ItemType;
  rotation: number;
  scale: number;
}

export interface BattleRecord {
  id: number;
  timestamp: string;
  p1Name: string;
  p2Name: string;
  p1Score: number;
  p2Score: number;
  winner: string;
  difficultyLabel?: string;
  p1MealLabel?: string;
  p2MealLabel?: string;
}

// Meal Types (affects density and label)
export enum MealType {
  BREAKFAST = 'BREAKFAST',
  LUNCH = 'LUNCH',
  DINNER = 'DINNER',
  TEA = 'TEA',
}

// Density Ratio requested: 3 : 6 : 5 : 1
// Density is inversely proportional to intervalMult.
export const MEAL_CONFIG = {
  [MealType.BREAKFAST]: { 
    label: '早饭', 
    // Density 3
    intervalMult: 0.83 
  },
  [MealType.LUNCH]: { 
    label: '午饭', 
    // Density 6 (Fastest)
    intervalMult: 0.42 
  },
  [MealType.DINNER]: { 
    label: '晚饭', 
    // Density 5
    intervalMult: 0.50 
  },
  [MealType.TEA]: { 
    label: '下午茶', 
    // Density 1 (Slowest)
    intervalMult: 2.50 
  },
};

// Difficulty Settings
// UPDATED: Density adjusted to ~50% of original for a more relaxed pace
export enum Difficulty {
  EASY = 'EASY',
  NORMAL = 'NORMAL',
  HARD = 'HARD',
}

export const DIFFICULTY_CONFIG = {
  [Difficulty.EASY]: {
    label: '拾荒者',
    description: '悠闲的采集时光 (速度慢)',
    speedMult: 0.7,
    spawnInterval: 1200, // Original ~600 -> 1200
  },
  [Difficulty.NORMAL]: {
    label: '农场主',
    description: '充实的农场生活 (标准)',
    speedMult: 1.0,
    spawnInterval: 800, // Original ~400 -> 800
  },
  [Difficulty.HARD]: {
    label: '齐先生的挑战',
    description: '极限反应测试 (速度快)',
    speedMult: 1.6,
    spawnInterval: 500, // Original ~250 -> 500
  }
};

// Item IDs
export enum ItemType {
  // Foods (Positive)
  STARDROP = 'STARDROP',
  PRISMATIC_SHARD = 'PRISMATIC_SHARD',
  MAGIC_ROCK_CANDY = 'MAGIC_ROCK_CANDY',
  PINK_CAKE = 'PINK_CAKE',
  SURVIVAL_BURGER = 'SURVIVAL_BURGER',
  SPICY_EEL = 'SPICY_EEL',
  PIZZA = 'PIZZA',
  COFFEE = 'COFFEE',
  SASHIMI = 'SASHIMI',
  MAKI_ROLL = 'MAKI_ROLL',
  SALAD = 'SALAD',
  SPAGHETTI = 'SPAGHETTI',
  FRIED_EGG = 'FRIED_EGG',
  COOKIES = 'COOKIES',
  
  // Monsters/Bad Items (Negative)
  GREEN_SLIME = 'GREEN_SLIME',
  BUG = 'BUG',
  FLY = 'FLY',
  DUGGY = 'DUGGY',
  GRUB = 'GRUB',
  ROCK_CRAB = 'ROCK_CRAB',
  BAT = 'BAT',
  STONE_GOLEM = 'STONE_GOLEM',
  GHOST = 'GHOST',
  SKELETON = 'SKELETON',
  LAVA_BAT = 'LAVA_BAT',
  LAVA_CRAB = 'LAVA_CRAB',
  LAVA_CRAB_SHELLLESS = 'LAVA_CRAB_SHELLLESS', 
  METAL_HEAD = 'METAL_HEAD',
  RED_SLIME = 'RED_SLIME',
  SHADOW_BRUTE = 'SHADOW_BRUTE',
  SHADOW_SHAMAN = 'SHADOW_SHAMAN',
  SQUID_KID = 'SQUID_KID',
  
  BOMB = 'BOMB',
}

export interface ItemConfig {
  id: ItemType;
  name: string;
  value: number;
  src: string;
  emoji: string;
}

// Helper to use CORS proxy for wiki images to avoid canvas tainting/broken state
const proxy = (url: string) => `https://images.weserv.nl/?url=${encodeURIComponent(url)}`;

// Stardew NPC Portraits
export const NPC_PORTRAITS = [
  proxy('https://stardewvalleywiki.com/mediawiki/images/b/b0/Abigail.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/0/04/Alex.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/b/bd/Elliott.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/2/28/Emily.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/1/1b/Haley.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/9/95/Harvey.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/e/e6/Leah.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/f/f8/Maru.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/a/ab/Penny.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/9/94/Sam.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/a/a8/Sebastian.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/8/8b/Shane.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/3/37/Caroline.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/8/88/Clint.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/c/c0/Demetrius.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/3/31/Dwarf.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/c/cf/Evelyn.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/7/7e/George.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/9/95/Gus.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/c/c7/Jas.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/4/46/Jodi.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/8/87/Kent.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/2/2b/Krobus.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/e/e0/Lewis.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/6/6f/Linus.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/1/1a/Marnie.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/9/90/Pam.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/b/b4/Pierre.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/e/e4/Robin.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/f/f6/Sandy.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/b/b2/Vincent.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/6/68/Willy.png'),
  proxy('https://stardewvalleywiki.com/mediawiki/images/4/4a/Wizard.png')
];

// Configuration with Image URLs from Stardew Wiki
export const ITEMS: Record<ItemType, ItemConfig> = {
  // --- GOOD ITEMS ---
  [ItemType.STARDROP]: {
    id: ItemType.STARDROP,
    name: '星之果实',
    value: 500,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/a/a5/Stardrop.png'),
    emoji: '🌟'
  },
  [ItemType.PRISMATIC_SHARD]: {
    id: ItemType.PRISMATIC_SHARD,
    name: '五彩碎片',
    value: 300,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/5/56/Prismatic_Shard.png'),
    emoji: '🌈'
  },
  [ItemType.MAGIC_ROCK_CANDY]: {
    id: ItemType.MAGIC_ROCK_CANDY,
    name: '魔法糖冰棍',
    value: 250,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/d/d9/Magic_Rock_Candy.png'),
    emoji: '🍬'
  },
  [ItemType.PINK_CAKE]: {
    id: ItemType.PINK_CAKE,
    name: '粉红蛋糕',
    value: 120,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/3/32/Pink_Cake.png'),
    emoji: '🍰'
  },
  [ItemType.SURVIVAL_BURGER]: {
    id: ItemType.SURVIVAL_BURGER,
    name: '生存汉堡',
    value: 80,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/8/87/Survival_Burger.png'),
    emoji: '🍔'
  },
  [ItemType.SPICY_EEL]: {
    id: ItemType.SPICY_EEL,
    name: '香辣鳗鱼',
    value: 100,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/f/f2/Spicy_Eel.png'),
    emoji: '🌶️'
  },
  [ItemType.PIZZA]: {
    id: ItemType.PIZZA,
    name: '披萨',
    value: 60,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/f/f4/Pizza.png'),
    emoji: '🍕'
  },
  [ItemType.COFFEE]: {
    id: ItemType.COFFEE,
    name: '咖啡',
    value: 30,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/e/e9/Coffee.png'),
    emoji: '☕'
  },
  [ItemType.SASHIMI]: {
    id: ItemType.SASHIMI,
    name: '生鱼片',
    value: 50,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/4/41/Sashimi.png'),
    emoji: '🐟'
  },
  [ItemType.MAKI_ROLL]: {
    id: ItemType.MAKI_ROLL,
    name: '寿司卷',
    value: 60,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/b/b6/Maki_Roll.png'),
    emoji: '🍣'
  },
  [ItemType.SALAD]: {
    id: ItemType.SALAD,
    name: '沙拉',
    value: 40,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/7/7e/Salad.png'),
    emoji: '🥗'
  },
  [ItemType.SPAGHETTI]: {
    id: ItemType.SPAGHETTI,
    name: '意大利面',
    value: 70,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/d/d1/Spaghetti.png'),
    emoji: '🍝'
  },
  [ItemType.FRIED_EGG]: {
    id: ItemType.FRIED_EGG,
    name: '荷包蛋',
    value: 25,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/1/18/Fried_Egg.png'),
    emoji: '🍳'
  },
  [ItemType.COOKIES]: {
    id: ItemType.COOKIES,
    name: '饼干',
    value: 45,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/7/70/Cookie.png'),
    emoji: '🍪'
  },

  // --- BAD ITEMS (MONSTERS) ---
  [ItemType.GREEN_SLIME]: {
    id: ItemType.GREEN_SLIME,
    name: '绿色史莱姆',
    value: -30,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/7/79/Green_Slime.png'),
    emoji: '🟢'
  },
  [ItemType.BUG]: {
    id: ItemType.BUG,
    name: '臭虫',
    value: -40,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/7/7d/Bug.png'),
    emoji: '🐛'
  },
  [ItemType.FLY]: {
    id: ItemType.FLY,
    name: '苍蝇',
    value: -40,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/d/d6/Cave_Fly.png'),
    emoji: '🪰'
  },
  [ItemType.DUGGY]: {
    id: ItemType.DUGGY,
    name: '掘地虫',
    value: -50,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/3/30/Duggy.png'),
    emoji: '🕳️'
  },
  [ItemType.GRUB]: {
    id: ItemType.GRUB,
    name: '蛆',
    value: -30,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/2/22/Grub.png'),
    emoji: '🐛'
  },
  [ItemType.ROCK_CRAB]: {
    id: ItemType.ROCK_CRAB,
    name: '岩石蟹',
    value: -60,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/d/d4/Rock_Crab.png'),
    emoji: '🦀'
  },
  [ItemType.BAT]: {
    id: ItemType.BAT,
    name: '蝙蝠',
    value: -50,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/f/f4/Bat.png'),
    emoji: '🦇'
  },
  [ItemType.STONE_GOLEM]: {
    id: ItemType.STONE_GOLEM,
    name: '石魔',
    value: -70,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/9/91/Stone_Golem.png'),
    emoji: '🗿'
  },
  [ItemType.GHOST]: {
    id: ItemType.GHOST,
    name: '幽灵',
    value: -80,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/a/a2/Ghost.png'),
    emoji: '👻'
  },
  [ItemType.SKELETON]: {
    id: ItemType.SKELETON,
    name: '骷髅',
    value: -70,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/2/23/Skeleton.png'),
    emoji: '💀'
  },
  [ItemType.LAVA_BAT]: {
    id: ItemType.LAVA_BAT,
    name: '熔岩蝙蝠',
    value: -90,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/7/76/Lava_Bat.png'),
    emoji: '🔥'
  },
  [ItemType.LAVA_CRAB]: {
    id: ItemType.LAVA_CRAB,
    name: '熔岩蟹',
    value: -100,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/1/1b/Lava_Crab.png'),
    emoji: '🦀'
  },
  [ItemType.LAVA_CRAB_SHELLLESS]: {
    id: ItemType.LAVA_CRAB_SHELLLESS,
    name: '无壳熔岩蟹',
    value: -110,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/6/66/Lava_Crab_%28dangerous%29.png'), // Using the "dangerous" or bare variant
    emoji: '🔴'
  },
  [ItemType.METAL_HEAD]: {
    id: ItemType.METAL_HEAD,
    name: '金属大头',
    value: -80,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/e/e5/Metal_Head.png'),
    emoji: '🤖'
  },
  [ItemType.RED_SLIME]: {
    id: ItemType.RED_SLIME,
    name: '红色史莱姆',
    value: -60,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/1/1e/Red_Slime.png'),
    emoji: '🔴'
  },
  [ItemType.SHADOW_BRUTE]: {
    id: ItemType.SHADOW_BRUTE,
    name: '暗影狂徒',
    value: -120,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/e/e0/Shadow_Brute.png'),
    emoji: '🌑'
  },
  [ItemType.SHADOW_SHAMAN]: {
    id: ItemType.SHADOW_SHAMAN,
    name: '暗影萨满',
    value: -150,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/f/f6/Shadow_Shaman.png'),
    emoji: '🧙'
  },
  [ItemType.SQUID_KID]: {
    id: ItemType.SQUID_KID,
    name: '鱿鱼娃',
    value: -80,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/a/ab/Squid_Kid.png'),
    emoji: '🦑'
  },

  // --- SPECIAL ---
  [ItemType.BOMB]: {
    id: ItemType.BOMB,
    name: '樱桃炸弹',
    value: -200,
    src: proxy('https://stardewvalleywiki.com/mediawiki/images/3/3b/Cherry_Bomb.png'),
    emoji: '💣'
  },
};

export const GAME_DURATION = 30; // seconds