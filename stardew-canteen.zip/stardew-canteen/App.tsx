import React, { useState, useEffect, useRef } from 'react';
import GameCanvas from './components/GameCanvas';
import { GameState, GAME_DURATION, BattleRecord, ITEMS, ItemType, NPC_PORTRAITS, Difficulty, DIFFICULTY_CONFIG, MealType, MEAL_CONFIG } from './types';
import { generateGameProphecy } from './services/prophecyService';
import { audioService } from './services/audioService';
import { Camera, Play, RotateCcw, Cloud, Star, Sparkles, Gem, Utensils, BookOpen, User, Gauge, Home, Leaf, Pause } from 'lucide-react';

// --- Easter Egg Components ---

const EasterEggs = () => {
  const [showUFO, setShowUFO] = useState(false);
  const [showJunimo, setShowJunimo] = useState(false);

  useEffect(() => {
    // Random UFO check every 10s
    const ufoInterval = setInterval(() => {
      if (Math.random() > 0.9) { // 10% chance
        setShowUFO(true);
        setTimeout(() => setShowUFO(false), 15000);
      }
    }, 10000);

    // Random Junimo check
    const junimoInterval = setInterval(() => {
      if (Math.random() > 0.8) {
         setShowJunimo(true);
         setTimeout(() => setShowJunimo(false), 4000);
      }
    }, 8000);

    return () => {
      clearInterval(ufoInterval);
      clearInterval(junimoInterval);
    };
  }, []);

  return (
    <div className="absolute inset-0 pointer-events-none z-10 overflow-hidden">
      {showUFO && (
        <div className="absolute top-10 -left-20 text-4xl animate-ufo opacity-80 filter sepia">
          🛸
        </div>
      )}
      {showJunimo && (
        <div className="absolute bottom-32 right-10 text-4xl animate-junimo transition-all duration-500">
           🍏
        </div>
      )}
    </div>
  );
};

// --- Player Avatar Component ---
const PlayerAvatar = ({ src, alt }: { src: string, alt: string }) => {
  const [error, setError] = useState(false);
  const [loaded, setLoaded] = useState(false);

  // Reset error state when src changes
  useEffect(() => {
    setError(false);
    setLoaded(false);
  }, [src]);

  return (
    <div className="w-full h-full relative flex items-center justify-center bg-[#e0c28e]">
      {/* Fallback Icon (Visible if error or loading) */}
      {(!loaded || error) && (
        <User className="text-[#5c3616] opacity-50 absolute z-10" size={32} />
      )}
      
      {/* Image */}
      {!error && (
        <img 
          src={src} 
          alt={alt} 
          className={`w-full h-full object-cover relative z-20 transition-opacity duration-300 ${loaded ? 'opacity-100' : 'opacity-0'}`}
          crossOrigin="anonymous"
          onLoad={() => setLoaded(true)}
          onError={() => setError(true)}
        />
      )}
    </div>
  );
};

// --- Grandpa Avatar Component (Unused but kept for reference or future use) ---
const GrandpaAvatar = () => {
  const [error, setError] = useState(false);
  const imgUrl = "https://stardewvalleywiki.com/mediawiki/images/8/88/Grandpa_Ghost.png";
  // Use proxy to avoid CORS/Hotlink issues
  const proxyUrl = `https://images.weserv.nl/?url=${encodeURIComponent(imgUrl)}`;

  if (error) {
    return (
      <div className="w-full h-full flex items-center justify-center bg-[#4a6b8c] rounded overflow-hidden border-2 border-[#5c3616]">
          <span className="text-3xl animate-pulse">👻</span>
      </div>
    );
  }

  return (
    <img 
      src={proxyUrl} 
      className="w-full h-full object-contain bg-[#2a2a2a] rounded border-2 border-[#5c3616]"
      alt="Grandpa"
      crossOrigin="anonymous"
      onError={() => setError(true)}
    />
  );
};

// --- Game Logo Component ---
// robustly handles image loading failure by showing a CSS styled alternative
const GameLogo = () => {
  const [error, setError] = useState(false);
  
  // Note: Since we cannot host the image, this URL acts as a placeholder.
  // The onError handler will immediately switch to the CSS fallback if this link is broken.
  const logoUrl = "https://i.imgur.com/REPLACE_WITH_YOUR_LOGO_URL.png"; 

  if (!error) {
    return (
      <div className="mb-8 relative group cursor-pointer transform hover:scale-105 transition-transform duration-300 z-50 w-full flex justify-center mt-8" onClick={() => audioService.playClick()}>
        <img 
          src={logoUrl} 
          alt="星露谷食堂" 
          className="h-32 md:h-52 w-auto object-contain drop-shadow-[0_10px_20px_rgba(0,0,0,0.4)] [image-rendering:pixelated]"
          onError={() => setError(true)}
        />
      </div>
    );
  }

  // Fallback CSS Logo (Mimics the provided image style)
  return (
    <div className="relative group cursor-pointer select-none transition-transform hover:scale-105 duration-300 z-50 mt-12 mb-8 flex justify-center" onClick={() => audioService.playClick()}>
      <div className="relative">
        {/* Decorative Leaves */}
        <Leaf className="absolute -top-8 -left-6 text-[#4ade80] fill-[#4ade80] stroke-[#14532d] w-12 h-12 rotate-[-45deg] drop-shadow-lg animate-bounce-slight" strokeWidth={2.5} />
        <Leaf className="absolute -top-6 -right-6 text-[#4ade80] fill-[#4ade80] stroke-[#14532d] w-10 h-10 rotate-[45deg] drop-shadow-lg animate-bounce-slight" style={{animationDelay: '0.5s'}} strokeWidth={2.5} />
        
        {/* Main Text Layering for 3D Wood Effect */}
        <h1 className="text-6xl md:text-8xl font-pixel relative z-10 text-[#ffb347] tracking-widest whitespace-nowrap"
            style={{
              fontFamily: '"ZCOOL KuaiLe", cursive',
              textShadow: `
                0px 2px 0px #b97a38,
                0px 4px 0px #b97a38,
                0px 6px 0px #5c3616,
                0px 8px 0px #5c3616,
                4px 12px 10px rgba(0,0,0,0.4)
              `,
              WebkitTextStroke: '2px #5c3616',
            }}
        >
          星露谷食堂
        </h1>
        
        {/* Wood Texture Overlay */}
        <div className="absolute inset-0 text-6xl md:text-8xl font-pixel tracking-widest whitespace-nowrap opacity-20 pointer-events-none z-20 mix-blend-overlay"
             style={{
               fontFamily: '"ZCOOL KuaiLe", cursive',
               backgroundImage: 'linear-gradient(180deg, transparent 50%, rgba(0,0,0,0.8) 50%)',
               backgroundSize: '100% 6px',
               color: 'transparent'
             }}
        >
          星露谷食堂
        </div>
        
         {/* Highlight */}
         <div className="absolute inset-0 text-6xl md:text-8xl font-pixel tracking-widest whitespace-nowrap opacity-90 pointer-events-none z-20"
             style={{
               fontFamily: '"ZCOOL KuaiLe", cursive',
               WebkitTextStroke: '0px transparent',
               backgroundImage: 'linear-gradient(180deg, rgba(255,255,255,0.4) 0%, transparent 40%)',
               backgroundClip: 'text',
               WebkitBackgroundClip: 'text',
               color: 'transparent'
             }}
        >
          星露谷食堂
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [gameState, setGameState] = useState<GameState>(GameState.LOADING);
  const [scoreP1, setScoreP1] = useState(0);
  const [scoreP2, setScoreP2] = useState(0);
  const [collectedItems, setCollectedItems] = useState<string[]>([]);
  const [timeLeft, setTimeLeft] = useState(GAME_DURATION);
  const [prophecy, setProphecy] = useState<string>("");
  
  // Customization & History
  const [p1Name, setP1Name] = useState("Player 1");
  const [p2Name, setP2Name] = useState("Player 2");

  // Difficulty & Meal
  const [difficulty, setDifficulty] = useState<Difficulty>(Difficulty.NORMAL);
  // Separate meal types for each player
  const [p1Meal, setP1Meal] = useState<MealType>(MealType.LUNCH);
  const [p2Meal, setP2Meal] = useState<MealType>(MealType.LUNCH);
  
  // Initialize random avatars immediately with lazy initialization
  const [p1Avatar, setP1Avatar] = useState(() => NPC_PORTRAITS[Math.floor(Math.random() * NPC_PORTRAITS.length)]);
  const [p2Avatar, setP2Avatar] = useState(() => NPC_PORTRAITS[Math.floor(Math.random() * NPC_PORTRAITS.length)]);
  
  const [history, setHistory] = useState<BattleRecord[]>([]);

  // Handle Game Over
  useEffect(() => {
    if (gameState === GameState.GAME_OVER) {
      audioService.stopBGM();
      audioService.playFanfare();
      
      // Use local prophecy generation (instant)
      const collectedNames = collectedItems.map(id => ITEMS[id as ItemType]?.name || id);
      generateGameProphecy(scoreP1, scoreP2, collectedItems)
        .then(text => {
          setProphecy(text);
        });

      const record: BattleRecord = {
        id: Date.now(),
        timestamp: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
        p1Name,
        p2Name,
        p1Score: scoreP1,
        p2Score: scoreP2,
        winner: scoreP1 > scoreP2 ? p1Name : scoreP2 > scoreP1 ? p2Name : "平局",
        difficultyLabel: DIFFICULTY_CONFIG[difficulty].label,
        p1MealLabel: MEAL_CONFIG[p1Meal].label,
        p2MealLabel: MEAL_CONFIG[p2Meal].label
      };
      setHistory(prev => [record, ...prev]);
    }
  }, [gameState]);

  const handleStartGame = () => {
    audioService.playClick();
    audioService.startBGM(); // Start music

    if (!p1Name.trim()) setP1Name("Player 1");
    if (!p2Name.trim()) setP2Name("Player 2");
    
    // Pick distinct random meal types
    const meals = Object.values(MealType);
    
    // Pick first meal
    const meal1Index = Math.floor(Math.random() * meals.length);
    const meal1 = meals[meal1Index];
    
    // Filter out the first picked meal to ensure distinctness
    const remainingMeals = meals.filter((_, index) => index !== meal1Index);
    const meal2 = remainingMeals[Math.floor(Math.random() * remainingMeals.length)];

    setP1Meal(meal1);
    setP2Meal(meal2);

    // Pick distinct random avatars for this session
    const shuffledAvatars = [...NPC_PORTRAITS].sort(() => 0.5 - Math.random());
    setP1Avatar(shuffledAvatars[0]);
    setP2Avatar(shuffledAvatars[1]);
    
    setScoreP1(0);
    setScoreP2(0);
    setCollectedItems([]);
    setTimeLeft(GAME_DURATION);
    setProphecy("");
    setGameState(GameState.PLAYING);
  };

  const handleReturnToMenu = () => {
    audioService.playClick();
    audioService.stopBGM();
    setGameState(GameState.MENU);
  };

  const handlePause = () => {
    if (gameState === GameState.PLAYING) {
        audioService.playClick();
        audioService.stopBGM();
        setGameState(GameState.PAUSED);
    }
  };

  const handleResume = () => {
      if (gameState === GameState.PAUSED) {
          audioService.playClick();
          audioService.startBGM();
          setGameState(GameState.PLAYING);
      }
  };

  const getWinner = () => {
    if (scoreP1 > scoreP2) return `${p1Name} 获胜!`;
    if (scoreP2 > scoreP1) return `${p2Name} 获胜!`;
    return "平局!";
  };

  return (
    <div className="min-h-screen w-full bg-[#fdd086] flex items-center justify-center p-2 sm:p-4 md:p-8 overflow-hidden relative selection:bg-[#ffdba3] selection:text-[#5c3616]">
      
      {/* Background Texture */}
      <div className="absolute inset-0 opacity-40 pointer-events-none" style={{
        backgroundColor: '#e0c28e',
        backgroundImage: `
          radial-gradient(circle at 50% 50%, transparent 0%, rgba(92, 54, 22, 0.1) 100%),
          repeating-linear-gradient(45deg, #d4b47d 0, #d4b47d 10px, #e0c28e 10px, #e0c28e 20px)
        `,
      }}></div>

      <EasterEggs />

      <div className="relative w-full max-w-5xl h-[85vh] stardew-panel rounded-lg shadow-2xl flex flex-col overflow-hidden z-20 bg-[#2a2a2a]">
        
        {/* Header UI */}
        <div className="w-full bg-[#d9a066] border-b-4 border-[#8b4513] p-3 flex justify-between items-center z-20 shadow-md relative">
          <div className="absolute inset-0 opacity-10 pointer-events-none" style={{backgroundImage: 'linear-gradient(90deg, transparent 50%, rgba(0,0,0,0.2) 50%)', backgroundSize: '4px 4px'}}></div>

          {/* Player 1 Score & Avatar */}
          <div className="flex items-center gap-3 relative z-10 shrink-0">
             <div className="w-14 h-14 bg-[#38bdf8] border-4 border-[#5c3616] shadow-[2px_2px_0_rgba(0,0,0,0.3)] flex items-center justify-center overflow-hidden bg-[#e0c28e] relative shrink-0">
                <PlayerAvatar src={p1Avatar} alt="P1" />
             </div>
             <div className="flex flex-col">
                <span className="font-pixel text-[#5c3616] text-[10px] bg-[#ffdba3] px-1 border border-[#b97a38] -mb-2 z-10 w-fit">{p1Name}</span>
                <div className="bg-[#5c3616] px-4 py-2 rounded-sm border-2 border-[#e8cfa6] text-[#ffdba3] min-w-[80px] text-center shadow-inner">
                  <span className="font-pixel text-xl">{scoreP1}</span>
                </div>
             </div>
          </div>

          {/* Timer */}
          <div className="flex flex-col items-center bg-[#5c3616] px-6 py-1 rounded-lg border-4 border-[#b97a38] shadow-[0_4px_0_rgba(0,0,0,0.4)] relative top-4 z-50 transform hover:scale-105 transition-transform shrink-0">
             <span className="text-[#e8cfa6] text-xs mb-1 font-bold tracking-widest">TIME</span>
             <span className={`font-pixel text-3xl ${timeLeft < 10 ? 'text-[#ff4444] animate-pulse' : 'text-white'} drop-shadow-md`}>
               {Math.ceil(timeLeft)}
             </span>
          </div>

          {/* Player 2 Score & Avatar */}
          <div className="flex items-center gap-3 flex-row-reverse relative z-10 shrink-0">
             <div className="w-14 h-14 bg-[#f472b6] border-4 border-[#5c3616] shadow-[2px_2px_0_rgba(0,0,0,0.3)] flex items-center justify-center overflow-hidden bg-[#e0c28e] relative shrink-0">
                <PlayerAvatar src={p2Avatar} alt="P2" />
             </div>
             <div className="flex flex-col items-end">
                <span className="font-pixel text-[#5c3616] text-[10px] bg-[#ffdba3] px-1 border border-[#b97a38] -mb-2 z-10 w-fit">{p2Name}</span>
                <div className="bg-[#5c3616] px-4 py-2 rounded-sm border-2 border-[#e8cfa6] text-[#ffdba3] min-w-[80px] text-center shadow-inner">
                  <span className="font-pixel text-xl">{scoreP2}</span>
                </div>
             </div>
          </div>
        </div>

        {/* Game Canvas */}
        <div className="flex-1 relative bg-[#2a2a2a] overflow-hidden">
          <GameCanvas 
            gameState={gameState} 
            setGameState={setGameState}
            setScoreP1={setScoreP1}
            setScoreP2={setScoreP2}
            setCollectedItems={setCollectedItems}
            setTimeLeft={setTimeLeft}
            player1Name={p1Name}
            player2Name={p2Name}
            player1Avatar={p1Avatar}
            player2Avatar={p2Avatar}
            difficulty={difficulty}
            p1Meal={p1Meal}
            p2Meal={p2Meal}
            onPause={handlePause}
          />
        </div>

        {/* Loading */}
        {gameState === GameState.LOADING && (
          <div className="absolute inset-0 bg-black/70 flex flex-col items-center justify-center text-white z-50">
            <div className="stardew-panel p-8 rounded-md flex flex-col items-center max-w-md text-center animate-bounce-slight">
              <div className="animate-spin mb-4 text-[#5c3616]"><Camera size={48} /></div>
              <p className="text-xl font-bold mb-2">正在载入资源...</p>
              <p className="text-sm text-[#5c3616]/80">请允许摄像头权限以开始游戏</p>
            </div>
          </div>
        )}

        {/* Pause Menu */}
        {gameState === GameState.PAUSED && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-50">
            <div className="stardew-panel p-8 rounded-lg max-w-sm w-full text-center flex flex-col gap-4 animate-in fade-in zoom-in duration-200">
               <h2 className="text-2xl font-bold text-[#5c3616] mb-2 border-b-2 border-[#b97a38] pb-2">游戏暂停</h2>
               
               <button 
                 onClick={handleResume}
                 className="stardew-btn py-3 rounded text-lg flex items-center justify-center gap-2 group"
               >
                 <Play size={20} fill="currentColor" />
                 继续游戏
               </button>
               
               <button 
                 onClick={handleReturnToMenu}
                 className="stardew-btn py-3 rounded text-lg flex items-center justify-center gap-2 group bg-[#d9a066]"
                 style={{backgroundColor: '#b97a38'}}
               >
                 <Home size={20} />
                 返回主菜单
               </button>
            </div>
          </div>
        )}

        {/* Menu */}
        {gameState === GameState.MENU && (
          <div className="absolute inset-0 bg-black/40 backdrop-blur-md flex flex-col items-center justify-center z-50 px-4">
             {/* Game Logo - Handles Image or Fallback */}
             <GameLogo />

             <div className="stardew-panel p-6 md:p-8 rounded-lg max-w-4xl w-full flex flex-col md:flex-row gap-8 shadow-[10px_10px_0_rgba(0,0,0,0.3)] relative z-40 bg-[url('https://www.transparenttextures.com/patterns/wood-pattern.png')]">
                <div className="flex-1 flex flex-col items-center">
                  <h2 className="text-2xl text-[#5c3616] mb-4 font-bold flex items-center gap-2 border-b-2 border-[#b97a38] pb-2 w-full justify-center">
                     <Utensils className="text-[#d94a1e]" /> 参赛农夫登记
                  </h2>
                  <div className="w-full space-y-3 mb-6">
                    <div className="relative group">
                      <label className="block text-xs font-bold text-[#5c3616] mb-1 pl-1">左侧玩家 (Player 1)</label>
                      <input 
                        type="text" 
                        value={p1Name}
                        onChange={(e) => setP1Name(e.target.value)}
                        className="w-full bg-[#ffdba3] border-4 border-[#8b4513] text-[#5c3616] font-pixel p-3 text-lg focus:outline-none focus:bg-white shadow-[inset_2px_2px_4px_rgba(0,0,0,0.2)] transition-colors"
                        placeholder="输入名字..."
                        maxLength={8}
                      />
                    </div>
                    <div className="relative group">
                      <label className="block text-xs font-bold text-[#5c3616] mb-1 pl-1">右侧玩家 (Player 2)</label>
                      <input 
                        type="text" 
                        value={p2Name}
                        onChange={(e) => setP2Name(e.target.value)}
                        className="w-full bg-[#ffdba3] border-4 border-[#8b4513] text-[#5c3616] font-pixel p-3 text-lg focus:outline-none focus:bg-white shadow-[inset_2px_2px_4px_rgba(0,0,0,0.2)] transition-colors"
                        placeholder="输入名字..."
                        maxLength={8}
                      />
                    </div>
                  </div>

                  {/* Difficulty Selector */}
                  <div className="w-full mb-6">
                    <h3 className="text-[#5c3616] font-bold mb-2 flex items-center gap-2 text-sm"><Gauge size={16} /> 挑战难度</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {Object.values(Difficulty).map((d) => {
                        const config = DIFFICULTY_CONFIG[d];
                        const isSelected = difficulty === d;
                        return (
                          <button
                            key={d}
                            onClick={() => {
                              setDifficulty(d);
                              audioService.playClick();
                            }}
                            className={`
                              relative flex flex-col items-center justify-center p-2 rounded border-2 transition-all duration-200
                              ${isSelected 
                                ? 'bg-[#ffdba3] border-[#5c3616] shadow-[inset_0_0_10px_rgba(92,54,22,0.2)] transform scale-105 z-10' 
                                : 'bg-[#e0c28e] border-[#b97a38] opacity-80 hover:opacity-100 hover:scale-105'
                              }
                            `}
                          >
                            <span className={`font-pixel text-xs md:text-sm ${isSelected ? 'font-bold' : ''}`} style={{color: isSelected ? '#5c3616' : '#8b4513'}}>
                              {config.label}
                            </span>
                            {isSelected && (
                              <div className="absolute -top-1 -right-1 text-yellow-500 animate-pulse text-xs">★</div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                    <div className="text-center mt-2 text-xs font-pixel text-[#8b4513] opacity-80 h-4">
                      {DIFFICULTY_CONFIG[difficulty].description}
                    </div>
                  </div>

                  <button 
                    onClick={handleStartGame}
                    className="stardew-btn w-full py-4 text-2xl font-bold rounded-lg flex items-center justify-center gap-3 hover:scale-[1.02] shadow-lg transition-all"
                  >
                    <Play fill="currentColor" size={24} />
                    开始比赛 (30秒)
                  </button>
                </div>

                <div className="w-full md:w-1/3 border-t-4 md:border-t-0 md:border-l-4 border-[#b97a38] pt-4 md:pt-0 md:pl-6 flex flex-col h-[350px] md:h-[500px]">
                   <h3 className="text-[#5c3616] font-bold mb-4 flex items-center gap-2 border-b-2 border-[#b97a38] pb-2">
                     <BookOpen size={20} className="text-[#d94a1e]" /> 社区中心记录
                   </h3>
                   <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar bg-[#e8cfa6] border-2 border-[#b97a38] rounded p-2 shadow-[inset_0_2px_4px_rgba(0,0,0,0.1)]">
                      {history.length === 0 ? (
                        <div className="text-center text-[#5c3616] opacity-50 mt-10 text-sm italic">
                          "那本旧书上一片空白..."<br/>快去创造历史吧！
                        </div>
                      ) : (
                        history.map((record) => (
                          <div key={record.id} className="bg-[#ffdba3] border-2 border-[#b97a38] p-2 mb-2 rounded text-xs text-[#5c3616] shadow-sm hover:translate-x-1 transition-transform cursor-default relative overflow-hidden group">
                            <div className="absolute top-0 right-0 p-1 opacity-20 text-[8px] font-bold group-hover:opacity-40">
                               {record.difficultyLabel} ({record.p1MealLabel || '?'} vs {record.p2MealLabel || '?'})
                            </div>
                            <div className="flex justify-between border-b border-[#b97a38] pb-1 mb-1 opacity-70">
                              <span>{record.timestamp}</span>
                              <span className="font-bold">{record.winner === "平局" ? "🤝" : "👑"}</span>
                            </div>
                            <div className="flex justify-between items-center">
                               <div className="flex flex-col">
                                 <span className={record.p1Score > record.p2Score ? "font-bold text-[#d94a1e]" : ""}>{record.p1Name}</span>
                                 <span>{record.p1Score}</span>
                               </div>
                               <span className="opacity-50 mx-1 text-lg">vs</span>
                               <div className="flex flex-col items-end">
                                 <span className={record.p2Score > record.p1Score ? "font-bold text-[#d94a1e]" : ""}>{record.p2Name}</span>
                                 <span>{record.p2Score}</span>
                               </div>
                            </div>
                          </div>
                        ))
                      )}
                   </div>
                </div>
             </div>
          </div>
        )}

        {/* Game Over */}
        {gameState === GameState.GAME_OVER && (
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center z-50 p-4">
            <div className="stardew-panel w-full max-w-2xl p-6 md:p-8 rounded-lg shadow-[0_0_50px_rgba(255,219,163,0.3)] flex flex-col items-center relative animate-in fade-in zoom-in duration-300 max-h-[90vh] overflow-y-auto z-40">
               <div className="absolute -top-6 -left-6 text-6xl animate-bounce delay-75">🎉</div>
               <div className="absolute -top-6 -right-6 text-6xl animate-bounce delay-150">🎉</div>
               <h2 className="text-3xl font-bold text-[#5c3616] mb-4 border-b-2 border-[#b97a38] pb-2 w-full text-center">
                 丰收节 结算
               </h2>
               <div className="flex flex-col items-center mb-6 w-full">
                 <div className="text-4xl md:text-5xl font-pixel text-[#d94a1e] drop-shadow-[2px_2px_0_#fff] mb-6 text-center animate-pulse">
                   {getWinner()}
                 </div>
                 <div className="flex gap-4 md:gap-12 bg-[#eac086] p-4 md:p-6 rounded border-2 border-[#cca370] shadow-inner w-full justify-center">
                   <div className="text-center transform transition-transform hover:scale-110">
                     <div className="text-[#38bdf8] font-pixel text-2xl md:text-3xl mb-2 drop-shadow-md">{p1Name}</div>
                     <div className="text-[#5c3616] font-pixel text-sm mb-4 opacity-80">({MEAL_CONFIG[p1Meal].label})</div>
                     <div className="text-4xl font-pixel text-[#5c3616] drop-shadow-sm">{scoreP1}</div>
                   </div>
                   <div className="w-1 bg-[#b97a38] h-32 self-center opacity-50" />
                   <div className="text-center transform transition-transform hover:scale-110">
                     <div className="text-[#f472b6] font-pixel text-2xl md:text-3xl mb-2 drop-shadow-md">{p2Name}</div>
                     <div className="text-[#5c3616] font-pixel text-sm mb-4 opacity-80">({MEAL_CONFIG[p2Meal].label})</div>
                     <div className="text-4xl font-pixel text-[#5c3616] drop-shadow-sm">{scoreP2}</div>
                   </div>
                 </div>
               </div>
               
               {/* Stardew Dialogue Box */}
               <div className="stardew-dialogue w-full p-2 mb-6 flex gap-3 relative shadow-lg">
                  {/* Text (No Avatar) */}
                  <div className="flex-1 flex flex-col justify-between py-1 px-2">
                      <div className="font-pixel text-[#8b4513] text-sm font-bold mb-1">爷爷</div>
                      <p className="text-[#5c3616] text-lg leading-tight font-bold tracking-wide flex-1 flex items-center">
                         “{prophecy}”
                      </p>
                      <div className="w-4 h-4 bg-[#d94a1e] rounded-full animate-bounce self-end mt-1"></div>
                  </div>
               </div>

               <div className="flex gap-4 w-full">
                 <button 
                   onClick={handleStartGame}
                   className="stardew-btn flex-1 py-4 rounded text-xl flex items-center justify-center gap-2 group"
                 >
                   <RotateCcw size={20} className="group-hover:-rotate-180 transition-transform duration-500" />
                   <span>再来一局</span>
                 </button>
                 <button 
                   onClick={handleReturnToMenu}
                   className="stardew-btn flex-1 py-4 rounded text-xl flex items-center justify-center gap-2 group bg-[#d9a066] border-[#8b4513]"
                   style={{backgroundColor: '#b97a38'}}
                 >
                   <Home size={20} />
                   <span>主菜单</span>
                 </button>
               </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}