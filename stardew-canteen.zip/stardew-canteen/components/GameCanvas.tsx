import React, { useEffect, useRef, useState, useCallback } from 'react';
import Webcam from 'react-webcam';
import { initializeFaceLandmarker, getLandmarker } from '../services/faceService';
import { GameState, Item, ItemType, ITEMS, GAME_DURATION, Difficulty, DIFFICULTY_CONFIG, MealType, MEAL_CONFIG } from '../types';
import { audioService } from '../services/audioService';
import { Pause, User } from 'lucide-react';

interface GameCanvasProps {
  gameState: GameState;
  setGameState: (state: GameState) => void;
  setScoreP1: (updater: (prev: number) => number) => void;
  setScoreP2: (updater: (prev: number) => number) => void;
  setCollectedItems: (updater: (prev: string[]) => string[]) => void;
  setTimeLeft: (time: number) => void;
  player1Name: string;
  player2Name: string;
  player1Avatar: string;
  player2Avatar: string;
  difficulty: Difficulty;
  p1Meal: MealType;
  p2Meal: MealType;
  onPause?: () => void;
}

interface PlayerState {
  id: number; // 1 or 2
  position: { x: number; y: number };
  mouthOpen: boolean;
  active: boolean; // Is face detected?
}

interface Feedback {
  id: number;
  x: number;
  y: number;
  text: string;
  color: string;
  createdAt: number;
}

const GameCanvas: React.FC<GameCanvasProps> = ({
  gameState,
  setGameState,
  setScoreP1,
  setScoreP2,
  setCollectedItems,
  setTimeLeft,
  player1Name,
  player2Name,
  player1Avatar,
  player2Avatar,
  difficulty,
  p1Meal,
  p2Meal,
  onPause,
}) => {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [players, setPlayers] = useState<PlayerState[]>([
    { id: 1, position: { x: 0, y: 0 }, mouthOpen: false, active: false },
    { id: 2, position: { x: 0, y: 0 }, mouthOpen: false, active: false }
  ]);

  const requestRef = useRef<number>(0);
  const itemsRef = useRef<Item[]>([]);
  const feedbacksRef = useRef<Feedback[]>([]);
  
  // Separate spawn timers for each player's side
  const lastSpawnTimeP1 = useRef<number>(0);
  const lastSpawnTimeP2 = useRef<number>(0);
  
  const startTimeRef = useRef<number>(0);
  // Store paused time to handle resume correctly (so time doesn't jump)
  const pausedAtRef = useRef<number>(0);
  
  const imagesRef = useRef<Record<string, HTMLImageElement>>({});

  useEffect(() => {
    initializeFaceLandmarker();
    Object.values(ITEMS).forEach(itemConfig => {
      const img = new Image();
      img.crossOrigin = "Anonymous";
      img.src = itemConfig.src;
      // Mark as loaded logic is handled by checking complete/naturalWidth in spawnItem
      imagesRef.current[itemConfig.id] = img;
    });
  }, []);

  // Handle start time management for pausing
  useEffect(() => {
    if (gameState === GameState.PLAYING) {
      if (pausedAtRef.current > 0) {
        // Resuming: Adjust start time by the duration we were paused
        const pauseDuration = Date.now() - pausedAtRef.current;
        startTimeRef.current += pauseDuration;
        pausedAtRef.current = 0;
      } else if (startTimeRef.current === 0) {
        // Fresh start
        startTimeRef.current = Date.now();
        itemsRef.current = [];
        feedbacksRef.current = [];
      }
    } else if (gameState === GameState.PAUSED) {
      if (pausedAtRef.current === 0) {
         pausedAtRef.current = Date.now();
      }
    } else {
       // Reset on other states
       startTimeRef.current = 0;
       pausedAtRef.current = 0;
    }
  }, [gameState]);

  // Updated spawnItem to accept a range [minX, maxX]
  const spawnItem = (minX: number, maxX: number) => {
    // 1. FILTER: Only select items that have successfully loaded images
    const validTypes = (Object.keys(ITEMS) as ItemType[]).filter(type => {
      const img = imagesRef.current[type];
      return img && img.complete && img.naturalWidth > 0;
    });

    if (validTypes.length === 0) return;

    // 2. PROBABILITY CONTROL
    const goodItems: ItemType[] = [];
    const badItems: ItemType[] = [];

    validTypes.forEach(type => {
      if (ITEMS[type].value >= 0) {
        goodItems.push(type);
      } else {
        badItems.push(type);
      }
    });

    let selectedType: ItemType;

    // 20% Chance for Bad Item
    const spawnBad = Math.random() < 0.2; 

    if (spawnBad && badItems.length > 0) {
      selectedType = badItems[Math.floor(Math.random() * badItems.length)];
    } else if (goodItems.length > 0) {
      selectedType = goodItems[Math.floor(Math.random() * goodItems.length)];
    } else {
      selectedType = validTypes[Math.floor(Math.random() * validTypes.length)];
    }
    
    // Ensure item spawns strictly within minX and maxX with some padding
    const padding = 40;
    // Handle cases where range is too small
    const safeMin = minX + padding;
    const safeMax = Math.max(safeMin, maxX - padding);
    
    const x = Math.random() * (safeMax - safeMin) + safeMin;

    const newItem: Item = {
      id: Date.now() + Math.random(),
      x,
      y: -80,
      type: selectedType,
      rotation: Math.random() * 360, 
      scale: 1.0,
    };
    itemsRef.current.push(newItem);
  };

  const gameLoop = useCallback((time: number) => {
    // We continue the loop even in PAUSED state to keep rendering the webcam/scene,
    // but we skip physics updates.
    if (gameState !== GameState.PLAYING && gameState !== GameState.PAUSED) return;

    const canvas = canvasRef.current;
    const webcam = webcamRef.current;
    const landmarker = getLandmarker();
    const config = DIFFICULTY_CONFIG[difficulty];
    const p1MealConfig = MEAL_CONFIG[p1Meal];
    const p2MealConfig = MEAL_CONFIG[p2Meal];

    const isPaused = gameState === GameState.PAUSED;

    if (canvas && webcam && webcam.video && landmarker) {
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      if (canvas.width !== webcam.video.videoWidth) {
        canvas.width = webcam.video.videoWidth;
        canvas.height = webcam.video.videoHeight;
      }

      // 1. Face Detection
      const currentPlayers: PlayerState[] = [
        { id: 1, position: { x: 0, y: 0 }, mouthOpen: false, active: false },
        { id: 2, position: { x: 0, y: 0 }, mouthOpen: false, active: false }
      ];

      if (webcam.video.readyState === 4) {
        const results = landmarker.detectForVideo(webcam.video, time);
        
        if (results.faceLandmarks && results.faceLandmarks.length > 0) {
          const detectedFaces = results.faceLandmarks.map((landmarks) => {
            const upperLip = landmarks[13];
            const lowerLip = landmarks[14];
            
            const x = (1 - (upperLip.x + lowerLip.x) / 2) * canvas.width;
            const y = (upperLip.y + lowerLip.y) / 2 * canvas.height;

            const faceHeight = Math.abs(landmarks[10].y - landmarks[152].y);
            const mouthDist = Math.abs(upperLip.y - lowerLip.y);
            const ratio = mouthDist / faceHeight;
            const isOpen = ratio > 0.08; 

            return { x, y, isOpen };
          });

          // Sort faces left-to-right to assign ID 1 (Left) and ID 2 (Right)
          detectedFaces.sort((a, b) => a.x - b.x);

          detectedFaces.forEach((face, index) => {
            if (index < 2) {
              currentPlayers[index].active = true;
              currentPlayers[index].position = { x: face.x, y: face.y };
              currentPlayers[index].mouthOpen = face.isOpen;
            }
          });
        }
      }

      setPlayers(currentPlayers);

      // 2. Clear
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.imageSmoothingEnabled = false;

      // Divider
      const centerX = canvas.width / 2;
      ctx.beginPath();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
      ctx.lineWidth = 4;
      ctx.setLineDash([20, 20]);
      ctx.moveTo(centerX, 0);
      ctx.lineTo(centerX, canvas.height);
      ctx.stroke();
      ctx.setLineDash([]);

      // --- LOGIC UPDATES ONLY IF NOT PAUSED ---
      if (!isPaused) {
          // 3. Spawning Logic
          
          // Player 1 (Left Side) Spawning
          const p1Interval = config.spawnInterval * p1MealConfig.intervalMult;
          if (time - lastSpawnTimeP1.current > p1Interval) {
            spawnItem(0, centerX); 
            lastSpawnTimeP1.current = time;
          }

          // Player 2 (Right Side) Spawning
          const p2Interval = config.spawnInterval * p2MealConfig.intervalMult;
          if (time - lastSpawnTimeP2.current > p2Interval) {
            spawnItem(centerX, canvas.width); 
            lastSpawnTimeP2.current = time;
          }

          const elapsed = (Date.now() - startTimeRef.current) / 1000;
          const remaining = Math.max(0, GAME_DURATION - elapsed);
          setTimeLeft(remaining);
          
          if (remaining <= 0) {
            setGameState(GameState.GAME_OVER);
            return; 
          }
      }

      // 4. Render Items
      for (let i = itemsRef.current.length - 1; i >= 0; i--) {
        const item = itemsRef.current[i];
        
        // Update Physics only if not paused
        if (!isPaused) {
            const speed = 6 * config.speedMult;
            item.y += speed; 
            item.x += Math.sin(item.y * 0.03 + item.id) * 1.5;
            item.rotation += 1;
        }

        ctx.save();
        ctx.translate(item.x, item.y);
        ctx.rotate(item.rotation * Math.PI / 180);
        
        const img = imagesRef.current[item.type];
        // 45px size (75% of original 60px base)
        const size = 45 * item.scale; 
        
        // Only draw if image is valid
        if (img && img.complete && img.naturalWidth > 0) {
          ctx.save();
          ctx.filter = 'brightness(0) opacity(0.5)';
          ctx.drawImage(img, -size/2 + 4, -size/2 + 4, size, size);
          ctx.restore();
          ctx.drawImage(img, -size/2, -size/2, size, size);
        }
        
        ctx.restore();

        if (!isPaused) {
            let eatenBy = 0;

            currentPlayers.forEach(p => {
                if (!p.active) return;
                const dx = p.position.x - item.x;
                const dy = p.position.y - item.y;
                const dist = Math.sqrt(dx*dx + dy*dy);
                
                // Collision radius reduced to 50 to match smaller size
                if (dist < 50 && p.mouthOpen) {
                    eatenBy = p.id;
                }
            });

            if (eatenBy > 0) {
              const val = ITEMS[item.type]?.value || 0;

              if (eatenBy === 1) setScoreP1(s => s + val);
              if (eatenBy === 2) setScoreP2(s => s + val);
              
              setCollectedItems(prev => [...prev, item.type]);
              
              // Sound Logic
              if (item.type === ItemType.BOMB) {
                audioService.playBomb();
              } else if (val < 0) {
                audioService.playBad(); 
              } else {
                audioService.playEat(); 
              }

              // Visual Feedback (Flash)
              ctx.save();
              ctx.beginPath();
              ctx.arc(item.x, item.y, 45, 0, Math.PI * 2);
              ctx.fillStyle = val > 0 
                ? (eatenBy === 1 ? 'rgba(56, 189, 248, 0.6)' : 'rgba(244, 114, 182, 0.6)')
                : 'rgba(0,0,0,0.6)';
              ctx.fill();
              
              if (item.type === ItemType.BOMB) {
                 ctx.beginPath();
                 ctx.arc(item.x, item.y, 55, 0, Math.PI * 2);
                 ctx.fillStyle = 'rgba(255, 68, 68, 0.8)';
                 ctx.fill();
              }
              ctx.restore();

              feedbacksRef.current.push({
                id: Math.random(),
                x: item.x,
                y: item.y,
                text: val > 0 ? `+${val}` : `${val}`,
                color: val > 0 ? '#4ade80' : '#ff4444',
                createdAt: performance.now()
              });

              itemsRef.current.splice(i, 1);
            } else if (item.y > canvas.height + 80) {
              itemsRef.current.splice(i, 1);
            }
        }
      }

      // 4.5 Feedbacks (Render only, don't update age if paused)
      const now = performance.now();
      
      if (!isPaused) {
          feedbacksRef.current = feedbacksRef.current.filter(fb => now - fb.createdAt < 800);
      }

      feedbacksRef.current.forEach(fb => {
         // Simplification: Just let them fade out even if paused (UI polish tradeoff)
         const age = now - fb.createdAt;
         const life = age / 800;
         const lift = life * 60; 
         const alpha = 1 - Math.pow(life, 3); 
         
         if (alpha > 0) {
            ctx.save();
            ctx.globalAlpha = alpha;
            ctx.font = "24px 'Press Start 2P'";
            ctx.fillStyle = fb.color;
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 4;
            ctx.textAlign = 'center';
            
            ctx.strokeText(fb.text, fb.x, fb.y - 40 - lift);
            ctx.fillText(fb.text, fb.x, fb.y - 40 - lift);
            ctx.restore();
         }
      });

      // 5. Players
      currentPlayers.forEach((p) => {
        if (!p.active) return;

        const name = p.id === 1 ? player1Name : player2Name;
        
        ctx.save();
        
        if (p.mouthOpen) {
          ctx.strokeStyle = '#4ade80';
          ctx.lineWidth = 4;
          ctx.setLineDash([8, 8]);
          ctx.strokeRect(p.position.x - 70, p.position.y - 70, 140, 140);
          ctx.setLineDash([]);
        }

        // Removed inner box logic here (ctx.rect, fill, stroke)
        
        ctx.font = "14px 'Press Start 2P'";
        ctx.fillStyle = "white";
        ctx.strokeStyle = "black";
        ctx.lineWidth = 4;
        ctx.textAlign = "center";
        
        // Name tag position relative to head center (slightly adjusted since inner box is gone)
        ctx.strokeText(name, p.position.x, p.position.y - 75);
        ctx.fillText(name, p.position.x, p.position.y - 75);
        
        ctx.restore();
      });
    }

    requestRef.current = requestAnimationFrame(() => gameLoop(performance.now()));
  }, [gameState, setGameState, setScoreP1, setScoreP2, setCollectedItems, setTimeLeft, player1Name, player2Name, difficulty, p1Meal, p2Meal]);

  // Start/Stop Loop
  useEffect(() => {
    if (gameState === GameState.PLAYING || gameState === GameState.PAUSED) {
       requestRef.current = requestAnimationFrame(() => gameLoop(performance.now()));
    } else {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    }
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [gameState, gameLoop]);

  return (
    <div className="relative w-full h-full overflow-hidden rounded-xl shadow-inner bg-[#2a2a2a] border-4 border-[#5c3616]">
      <Webcam
        ref={webcamRef}
        mirrored
        className="absolute inset-0 w-full h-full object-cover opacity-90"
        style={{
          filter: 'contrast(1.1) saturate(1.2) sepia(0.3) blur(0.4px)' 
        }}
        onUserMedia={() => {
           if(gameState === GameState.LOADING) setGameState(GameState.MENU);
        }}
      />
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full object-cover rendering-pixelated"
      />
      
      {(gameState === GameState.PLAYING || gameState === GameState.PAUSED) && (
        <>
          <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-[#5c3616] p-2 border border-[#b97a38] opacity-90 rounded-sm shadow-md transition-all duration-300">
            <div className="w-8 h-8 rounded border border-[#b97a38] overflow-hidden bg-[#e0c28e] flex items-center justify-center">
              {player1Avatar ? (
                  <img src={player1Avatar} alt="P1" className="w-full h-full object-cover" crossOrigin="anonymous" onError={(e) => e.currentTarget.style.display = 'none'} />
              ) : <User size={16} className="text-[#5c3616]" />}
            </div>
            <div className="text-white font-pixel text-[10px] drop-shadow-md">{player1Name} 的{MEAL_CONFIG[p1Meal].label}</div>
          </div>
          <div className="absolute bottom-4 right-4 flex items-center gap-2 flex-row-reverse bg-[#5c3616] p-2 border border-[#b97a38] opacity-90 rounded-sm shadow-md transition-all duration-300">
            <div className="w-8 h-8 rounded border border-[#b97a38] overflow-hidden bg-[#e0c28e] flex items-center justify-center">
              {player2Avatar ? (
                  <img src={player2Avatar} alt="P2" className="w-full h-full object-cover" crossOrigin="anonymous" onError={(e) => e.currentTarget.style.display = 'none'} />
              ) : <User size={16} className="text-[#5c3616]" />}
            </div>
            <div className="text-white font-pixel text-[10px] drop-shadow-md">{player2Name} 的{MEAL_CONFIG[p2Meal].label}</div>
          </div>
          
          {/* Pause Button - Centered */}
          {gameState === GameState.PLAYING && onPause && (
             <button 
               onClick={onPause}
               className="absolute top-2 left-1/2 transform -translate-x-1/2 bg-[#d94a1e] border-2 border-[#861c1c] text-white p-2 rounded-full shadow-md hover:scale-110 active:scale-95 transition-all z-50 flex items-center justify-center w-10 h-10"
             >
                <Pause size={20} fill="white" />
             </button>
          )}
        </>
      )}
    </div>
  );
};

export default GameCanvas;